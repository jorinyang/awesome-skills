---
name: content-expiry-check
description: Feishu Wiki content expiry checker — scan nodes, apply category-based expiry rules, mark expired docs with comments
triggers:
  - "过期校验"
  - "expiry check"
  - "check for expired"
  - "扫描过期"
tags: [feishu, wiki, expiry, travel-intel]
category: travel
version: 1.0.0
dependencies:
  commands: [curl, lark-cli]
  env: [FEISHU_APP_ID, FEISHU_APP_SECRET]
---

# Content Expiry Check — Feishu Wiki 文档过期校验

> 用于 cron 定时扫描飞书知识库节点，按内容分类规则判定过期，添加评论标记。

## 15 类过期规则

按正则匹配顺序判定（首个命中即停）：

| 顺序 | 分类 | 阈值 | 正则特征 |
|:----:|------|:----:|---------|
| 1 | 社媒热议话题 | 7d | 社媒/热搜/热议/话题/微博/知乎/热榜 |
| 2 | 竞品社媒动态 | 14d | 竞品+社媒/社交/话题/微博/知乎/小红书 |
| 3 | 竞品价格 | 14d | 竞品+价格/降价/涨价/调价/促销/优惠 |
| 4 | 竞品新品/营销 | 30d | 竞品/新品/营销/探洞/天坑/桨板/SUP/坝盘 |
| 5 | 节庆/活动 | 14d | 节庆/赛事/活动/音乐节/嘉年华/开幕/启幕/暑期 |
| 6 | 门票/开放时间 | 30d | 门票/免票/票价/收费/优惠票/免费/半价/折扣 |
| 7 | 酒店/交通价格 | 30d | 酒店/民宿/机票/高铁 + 价格/涨价/促销 |
| 8 | 政策法规(地方) | 60d | 政策/通知/通告 + 省/市/县/文旅厅/旅游局 |
| 9 | 政策法规(国家) | 180d | 国务院/国家/文旅部/统计局 + 政策/规划/公报 |
| 10 | 酒店设施/交通线路 | 90d | 酒店/民宿/交通/高铁/航线/开业/新开 |
| 11 | 行业报告/趋势 | 90d | 报告/趋势/洞察/分析/周度/统计/数据 |
| 12 | 季节性信息 | 90d | 季节/春季/夏季/赏花/避暑/滑雪/温泉 |
| 13 | 攻略/游记/评价 | 365d | 攻略/游记/推荐/点评/打卡/路线/行程 |
| 14 | 景点基础信息 | 180d | 景点/景区/5A/4A/地质公园/名山/古镇 |
| 15 | 未分类（默认） | 60d | 未匹配以上任何规则 |

## 日期提取策略（优先级）

1. **标题前缀** — 匹配 `YYYY-MM-DD_` 格式（自动化采集文档的命名规范）
2. **obj_edit_time** — REST API 返回的 Unix 时间戳（curl 方式可获取；lark-cli wiki +node-list 不返回此字段）
3. **放弃** — 无法获取日期时跳过（计入 no_date 计数）

## 执行

```bash
python3 scripts/expiry_checker.py
```

脚本自动：
- 获取 tenant_access_token（需 `FEISHU_APP_ID`/`FEISHU_APP_SECRET` 环境变量）
- 逐页扫描目标节点（处理 page_token 分页，3次重试）
- 分类 → 日期提取 → 过期判定
- 过期文档：调用 `lark-cli drive +add-comment --full-comment` 标记
- 输出结构化报告（过期数/标记数/跳过数/年龄分布/分类分布）

## 目标节点配置

编辑脚本顶部的 `TARGET_NODES` 字典。默认节点：
- 行业资讯: `V0Lhwl7KYiWYDDk1vCncv2GhnYf`
- 竞品动态: `EAMYw1CPoipVWtkObbtcR2oDnNc`

Space ID: `7643710721485753535`

## 已知陷阱

### write_file 写入 Python 脚本时 f-string 含 token 变量会被截断

症状：`write_file` 写入包含 `f"...Bearer ***` 的 Python 代码时，`{token}` 部分导致行截断和 SyntaxError。

**对策：** 不用 f-string，改用字符串拼接：
```python
# WRONG — gets mangled by write_file
hdr = f"Authorization: Bearer ***
# CORRECT
hdr = "Authorization:" + " " + "Bearer" + " " + token
```

### lark-cli 不转发 query 参数

`lark-cli api` 对含 `?key=value` 的端点不转发 query 参数。**所有需要 query 参数的 API 调用必须使用 curl + tenant_access_token。**

### 分页超时

Feishu REST API 对大节点（>500 docs）的分页请求可能超时。脚本内置 3 次重试（每次 5s 间隔），`--max-time 60`。

### 飞书频率限制

标记过期文档时每条评论间隔 ≥0.5s，避免触发 rate limit。
