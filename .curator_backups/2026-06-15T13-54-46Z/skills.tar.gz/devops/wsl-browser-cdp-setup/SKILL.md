---
name: wsl-browser-cdp-setup
description: Connect Hermes browser tools or agent-browser CLI to Windows Chrome/Edge via CDP when running in WSL without a display. Use when browser_navigate/browser_snapshot fail with Node.js PATH errors or when WSL headless needs a real browser.
---

# WSL Browser CDP Setup

When Hermes or agent-browser runs inside WSL without a display server (no X11/Wayland), the local Chromium backend cannot launch. This skill covers connecting to the Windows host's Chrome/Edge via Chrome DevTools Protocol (CDP) — including Node.js PATH fixes, Chrome auto-launch, and Hermes config.

## Quick diagnostic

```bash
# Check if WSL
grep -qi "microsoft\|wsl" /proc/version && echo "WSL detected" || echo "not WSL"
# Check display
echo "DISPLAY=$DISPLAY WAYLAND=$WAYLAND_DISPLAY"
# Check Node.js PATH for browser subprocesses
env -i PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin" /usr/bin/env node --version 2>&1
```

## Step 1: Fix Node.js PATH for browser subprocesses

Hermes browser tools spawn subprocesses with clean environment (default PATH only). If `node` is only available via user PATH (`~/.local/bin`, `~/.hermes/node/bin`), browser tools fail with:
```
/usr/bin/env: 'node': No such file or directory
```

**Fix — system-wide symlink (requires sudo once):**
```bash
sudo ln -sf ~/.hermes/node/bin/node /usr/local/bin/node
```

If no sudo, verify the symlink already exists or check `~/bin/node`.

Verify:
```bash
env -i PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin" node --version
```

## Step 2: Start Windows Chrome with CDP

### Find Chrome/Edge on Windows

From WSL, Windows executables are accessible via `/mnt/c/`:
```bash
# Check Chrome
ls "/mnt/c/Program Files/Google/Chrome/Application/chrome.exe"
# Check Edge
ls "/mnt/c/Program Files (x86)/Microsoft/Edge/Application/msedge.exe"
```

### Get Windows host IP

```bash
# Primary: /etc/resolv.conf nameserver
grep nameserver /etc/resolv.conf | awk '{print $2}'
# Fallback: default gateway
ip route show default | awk '{print $3}'
```

The typical WSL2 Windows host IP is `172.x.x.1`.

### Launch Chrome with remote debugging

```bash
WINDOWS_HOST=$(grep nameserver /etc/resolv.conf | awk '{print $2}')

"/mnt/c/Program Files/Google/Chrome/Application/chrome.exe" \
  --remote-debugging-port=9222 \
  --remote-debugging-address=0.0.0.0 \
  --user-data-dir="C:\temp\chrome-cdp" \
  --no-first-run \
  --no-default-browser-check \
  --headless=new \
  &
```

Key flags:
- `--remote-debugging-address=0.0.0.0` — required for WSL to reach the port
- `--user-data-dir="C:\temp\chrome-cdp"` — isolated profile, won't conflict with user's normal Chrome
- `--headless=new` — no visible window for background automation

### Verify CDP is reachable

```bash
curl -s "http://${WINDOWS_HOST}:9222/json/version" | python3 -m json.tool | head -10
```

Expected response includes `"Browser": "Chrome/...", "webSocketDebuggerUrl": "ws://..."`

## Step 3: Configure Hermes to use CDP

```bash
hermes config set browser.cdp_url "http://${WINDOWS_HOST}:9222"
```

This sets `browser.cdp_url` in `~/.hermes/config.yaml` (or profile-specific config). The CDP endpoint persists across sessions.

After configuration, all browser tools (`browser_navigate`, `browser_snapshot`, `browser_click`, `browser_console`) automatically connect to the Windows Chrome instance.

Verify with:
```bash
hermes config show | grep -A3 browser
```

## Step 4: Use agent-browser CLI directly (alternative)

agent-browser CLI (v0.27+) has native `--auto-connect` and `--cdp` flags:

```bash
# Connect to already-running CDP
agent-browser --cdp 9222 snapshot

# Auto-discover and connect
agent-browser --auto-connect snapshot

# Or via env var
AGENT_BROWSER_AUTO_CONNECT=1 agent-browser snapshot
```

In WSL without a display, `--auto-connect` will:
1. Probe `127.0.0.1:9222,9229`
2. Connect if a Linux Chrome is running
3. **Fall back to WSL detection** (requires agent-browser ≥ v0.28 or PR #1449 merged) — finds Windows Chrome, launches if needed

Source repo: `github.com/vercel-labs/agent-browser` (Rust, Apache-2.0)

## Pitfalls

- **Node.js not in default PATH**: The most common blocker. Fix with Step 1 symlink.
- **`browser_navigate` returns `Could not connect to CDP`**: Check that Chrome is running with `--remote-debugging-port` and `--remote-debugging-address=0.0.0.0`. Verify with `curl http://<host>:9222/json/version`.
- **CDP port not reachable from WSL**: If Chrome is bound to `127.0.0.1` only (default), WSL cannot reach it. Must use `--remote-debugging-address=0.0.0.0` or `netsh portproxy`.
- **Windows host IP changes on reboot**: DHCP may reassign. Use `/etc/resolv.conf` nameserver (WSL updates this on every start).
- **Chrome user-data-dir conflict**: If Chrome says "profile is in use", kill the existing Chrome CDP instance or use a different `--user-data-dir` path.
- **First-launch login**: New `--user-data-dir` has no cookies/sessions. User must log into web services manually in the initial browser window.
- **agent-browser not installed**: `npm install -g agent-browser && agent-browser install`

## Full startup script

See `scripts/wsl-chrome-cdp.sh` for a one-command launcher that handles Steps 1-3.

## Reference files

- `references/chrome-cdp-flags.md` — Complete Chrome CDP flag reference
- `scripts/wsl-chrome-cdp.sh` — One-command WSL Chrome CDP launcher
