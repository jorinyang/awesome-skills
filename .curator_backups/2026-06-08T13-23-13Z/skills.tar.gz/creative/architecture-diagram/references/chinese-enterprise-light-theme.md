# Light-Theme / Chinese Enterprise Variant

When a user asks for "白底黑字" (white background, black text), "蓝字标注，红字强调" (blue annotations, red emphasis), or explicitly requests a Chinese enterprise/business diagram style rather than the default dark tech aesthetic, use this variant.

## Color Palette

| Role | Color | Usage |
|------|-------|-------|
| Background | `#FFFFFF` | Page and cell backgrounds |
| Text (primary) | `#0F172A` / `#1a1a2e` | Headers, body text |
| Text (secondary) | `#475569` | Descriptions |
| Text (muted) | `#64748B` / `#94A3B8` | Subtitles, footnotes |
| Blue annotation | `#1F3A8A` / `#2563EB` / `#3B5BDB` | Key labels, dimension names, actions (▸) |
| Red emphasis | `#DC2626` / `#B91C1C` | Warnings ⚠, risks, key metrics, "上移" badges |
| Green (value) | `#15803D` / `#10B981` | Business value metrics, growth |
| Amber (boss/action) | `#92400E` | Boss action items (◆), strategic items |
| Cell borders | `#E2E8F0` | Default cell borders |
| Stage colors | L0=`#94A3B8`, L1=`#3B5BDB`, L2=`#7C3AED`, L3=`#06B6D4` | Stage header accent borders |

## Typography

- **Font**: `"PingFang SC", "HarmonyOS Sans SC", "Microsoft YaHei", sans-serif` — never JetBrains Mono for Chinese content
- **Sizes**: Title 13-15px, Section headers 10-12px, Cell content 9-10px, Tags 9-10px, Footnotes 7-8px
- **English labels**: Use `font-family="sans-serif"` for short English words (DIGITALIZATION MATURITY, BUSINESS VALUE, HQ/SC/SR)

## Cell Layout Guidelines

When building matrix/grid diagrams with cells:
- **Height**: 70-75px per cell gives adequate room for tags + 2-3 text lines with spacing
- **Spacing**: Leave an empty line (~16-18px) between tag row and content text
- **Tag height**: 16-18px with rx=4-5, font 9-10px
- **Content text**: 10px font, ~18px line spacing
- **Centered layout** (tags centered on top, text centered below) is preferred over left-right split unless user explicitly asks otherwise

## 16:9 Full-Page Requirement

When the user asks for a 16:9 diagram:
- The **entire HTML page** must be 16:9, not just the SVG viewBox
- Use `viewBox="0 0 1920 1080"` and CSS `width:100vw; height:100vh`
- All content (headers, grid, summary cards, legend, footer) fits within the 1920×1080 canvas
- Do NOT put content outside the SVG (no HTML cards below the SVG)

## Design Iteration Flow

When the user provides source content + reference template:
1. Ask clarify questions FIRST — do not jump to implementation
2. Understand: which content permeates existing cells vs. becomes new rows
3. Start with the simpler approach (centered layout), only go horizontal/left-right if explicitly asked
4. Build incrementally; the user will often refine after seeing the result
