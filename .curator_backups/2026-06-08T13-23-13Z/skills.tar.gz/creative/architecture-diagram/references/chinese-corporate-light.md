# Chinese Corporate Light Variant (中国式企业架构图)

When the user asks for a business architecture/maturity model diagram in a Chinese corporate context, use this light/variant instead of the default dark theme.

## Key Design Rules

| Rule | Value |
|------|-------|
| Background | `#FFFFFF` (white) |
| Primary text | `#0F172A` / `#475569` (black/grey) |
| Labels & actions | `#2563EB` / `#1D4ED8` (blue) |
| Emphasis & risks | `#DC2626` (red) |
| Font family | `'PingFang SC','HarmonyOS Sans SC','Microsoft YaHei',sans-serif` |
| Aspect ratio | Strict 16:9 — `viewBox="0 0 1920 1080"` |
| Alignment | All cell content horizontally & vertically centered (`text-anchor="middle"` + cy-based positioning) |

## Cell Content Centering Pattern

For a grid row at `y` with height `h`, cell center_y = `y + h/2`:
- Tags line: `cy - 16` (horizontally centered, compute tag group width and offset from column center_x)
- Text lines: `cy - 2`, `cy + 12`, `cy + 26` (all `text-anchor="middle"` at column center_x)

## Stage Header Pattern (四阶段)

Each stage column gets a colored top-border and light-tinted background:
- L0: `#94A3B8` (slate) — `fill="#F8FAFC"`
- L1: `#3B5BDB` (blue) — `fill="#EFF6FF"`
- L2: `#7C3AED` (indigo) — `fill="#EEF2FF"`
- L3: `#06B6D4` (cyan) — `fill="#ECFEFF"`

## Tag Pill Pattern

Color-coded rounded pills with centered text:
- System tags: `fill="#EFF6FF" stroke="#BFDBFE"` blue text
- AI tags: `fill="#FEF2F2" stroke="#FECACA"` red text
- Org tags: `fill="#F0FDF4" stroke="#BBF7D0"` green text
- Boss tags: `fill="#FFFDF5" stroke="#FDE68A"` amber text
- Risk tags: `fill="#FEE2E2"` red text

## Font Size Guide (1920×1080 canvas)

| Element | Size |
|---------|------|
| Page title | 15px bold |
| Stage header number | 28px bold |
| Stage header name | 12px bold |
| Grid cell text | 9px |
| Grid cell tags | 8-9px |
| Enterprise app pills | 10px |
| Quote main line | 13px italic |
| Legend | 8px |
| Card titles | 10px bold |
| Card body | 9px |
