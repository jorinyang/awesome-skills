# Chinese Business Architecture Diagram — Light Theme Variant

When the user requests a Chinese business architecture diagram (业务架构图), the dark theme/JetBrains Mono defaults of architecture-diagram are NOT appropriate. Apply this variant instead.

## Trigger
- User mentions 业务架构图/全景地图/转型升级 + Chinese content
- User provides Chinese business content for diagramming
- User references an existing Chinese business HTML document as style template

## Visual System

### Background & Typography
- Background: `#FAFBFD` (warm white, not `#020617` dark)
- Font: `"PingFang SC","HarmonyOS Sans SC","Microsoft YaHei",sans-serif` — NOT JetBrains Mono
- The original document's CSS variables and tag system should be referenced, not the ClawShell dark template

### Color Coding (Chinese Business Convention)
| Usage | Color |
|-------|-------|
| Black text (正文) | `#0F172A` / `#475569` |
| Blue annotations (蓝字标注) | `#1D4ED8` / `#3B5BDB` / `#2563EB` |
| Red emphasis (红字强调) | `#DC2626` / `#B91C1C` |
| Risks/warnings | `#DC2626` on `#FFF5F5` background |
| Boss/leader actions | `#92400E` on `#FFFDF5` background |
| Business value/positive | `#15803D` on `#F0FDF4` background |
| Gray secondary | `#64748B` / `#94A3B8` |

### Stage Color Progression
- L0 (slate): `#94A3B8` border, `#F8FAFC` fill, `#64748B` text
- L1 (blue): `#3B5BDB` border, `#EFF6FF` fill, `#1F3A8A` text
- L2 (purple): `#7C3AED` border, `#EEF2FF` fill, `#4F46E5` text
- L3 (cyan): `#06B6D4` border, `#ECFEFF` fill, `#0E7490` text

### Tags/Pills (Chinese Business Style)
```svg
<rect x="..." y="..." width="W" height="14" rx="5" fill="..." stroke="..." stroke-width=".5"/>
<text x="center" y="baseline" fill="..." font-size="8" font-weight="600" text-anchor="middle">Label</text>
```
Tag fills by type: system=#EFF6FF, AI=#FEF2F2, org=#F0FDF4, boss=#FFFDF5, risk=#FEE2E2

## 16:9 Full-Page Requirement

CRITICAL: When the user says "16:9", they mean the ENTIRE HTML page, not just the SVG viewBox.

```css
html,body{width:100%;height:100%;overflow:hidden}
svg{width:100vw;height:100vh}
```

```svg
<svg viewBox="0 0 1920 1080" ...>
```

ALL content (headers, rows, cards, legend, footer) lives inside the single SVG. No external HTML cards or sections below the SVG.

## Content Centering in Grid Cells

For matrix-style diagrams (stages × dimensions):
1. Tags/pills: group them, calculate total width, position centered on cell center-x
2. Text lines: `text-anchor="middle"` with x = column center-x
3. Vertical: calculate content block height, position so block center ≈ cell center-y
4. All cells in a row should use the same Y offsets for visual consistency

## Enterprise Application Section

When showing enterprise apps as a row of pills:
- Box height: ~52px (allows for title + pill row)
- Title font: 10px, positioned near box top-center
- Pill font: 9px (NOT 7.5px — too small for Chinese)
- Pill height: 16px, rx: 5
- Pills vertically centered in the remaining space below title

## Grid Row Layout Pattern

**Default — Vertical centering (tags top, text below):**
```
row_y = base
cell_h = 68-72
center_y = row_y + cell_h/2
tags_y = row_y + 8 (centered horizontally across cell width)
text_line1_y = center based on content block centering
text_line2_y = text_line1_y + 14
text_line3_y = text_line2_y + 14 (if needed)
```

**Horizontal variant (tags left, content right) — preferred when cells feel too empty:**
The user may ask for "标签左，内容右" or "横向排布". This fills cells better than vertical stacking.

```
Cell layout (58px tall, ~425px wide):
┌──────────────────────────────────────┐
│ [Tag1]          · Content line 1     │
│ [Tag2]          · Content line 2     │
│ [Tag3] [L1-L6]  ▸ Action line        │
└──────────────────────────────────────┘

Left column (x = cell_x + 12, width ~120-140px):
  - Tags stacked vertically, 18px tall each, 4px gap
  - 3-4 tags fill the cell height
  - Font: 9-10px, bold

Right column (x = cell_x + 155, width ~280-300px):
  - 2-3 text lines at 10px font
  - Line spacing: 17px
  - Left-aligned (text-anchor="start")
```

Key rules for horizontal layout:
- Cell height: 58px (NOT 56px — too cramped for 3 text rows + 3 tag rows)
- Content text at 10px (NOT 8.5px — cell must feel "充实")
- Tags at 9-10px font, font-weight="600" or "700"
- Layer labels (L1, L2+L6, L3-L5, etc.) as the bottom tag in the left column
- Risk cells: risk-type tag on left, warning + solution text on right

## Pitfalls

1. **DO NOT** use JetBrains Mono for Chinese business content — it's a code font
2. **DO NOT** use dark theme (`#020617`) unless user explicitly asks for it
3. **DO NOT** put content outside the SVG when user asks for 16:9
4. **DO NOT** use 7.5px font for Chinese text — minimum 9px for readability
5. **DO** reference the user's provided HTML document for CSS variable names and tag styles
8. **DO** use text-anchor="middle" for centered text in grid cells
9. **DO** mirror the original document's color palette exactly rather than substituting
10. **DO NOT** default to vertical-centered layout when user says "框体太空了" or "标签左内容右" — switch to horizontal layout immediately
11. **DO NOT** use vertical tag stacking when cells have 3+ content lines — it wastes horizontal space. Tags left + text right fills more naturally
12. **DO NOT** persist with horizontal layout if user says "回退到标签居中" or sends an image showing tags exceeding cell boundaries. Revert to centered layout without arguing.
13. **DO NOT** use small fonts (10px/7px) in sidebar label boxes — the user will say "框体太空了". Minimum 14px title, 10px subtitle.
14. **DO** verify after EVERY batch edit that no `<text>` x-coordinate has drifted into the sidebar zone (x < 160). The sidebar is at x=20, width=130; text overlapping it is a bug. Quick check: `grep -c 'text-anchor="start"' file.html` must be 0; Python check: `re.findall(r'<text x="(\\d+)"', c)` — any x < 160 and x > 86 is a leak unless it's a legend swatch label.
15. **DO NOT** guess what "回滚到N个版本之前" means — there are too many edit rounds to count. Instead, use clarify() with numbered options describing specific states (e.g., "左对齐+等高行距", "居中但标签x未修正", "只撤销标签居中修正", "只撤销侧边栏字号改动"). The user will pick one.
16. **DO** run a font-size verification pass after any edit touching sidebar labels: `grep -n 'x="85".*font-size' file.html | grep -v 'font-size="14"' | grep -v 'font-size="10"'` — any remaining 8px/9px on sidebar labels is a bug.
18. **DO NOT** use emoji in SVGs that will be converted to PNG for Feishu embedding — cairosvg on Linux renders emoji as empty boxes or X marks. Use HTML entities instead: ▶ = `&#9654;`, → = `&#8594;`, ◆ = `&#9670;`. Also, `font-family` MUST use Linux-available Chinese fonts: `"Noto Sans SC", "SimSun", sans-serif` — NOT `"PingFang SC"` which is macOS-only.

## Progressive Font Enlargement

When the user says "文字适当放大" or "框体太空了", this is iterative — not one-and-done. After the first round, expect additional enlargement requests. Start conservative but be ready to scale up:

| Iteration | Enterprise Title | Pill Font | Pill Height | Box Height |
|-----------|-----------------|-----------|-------------|------------|
| Default   | 9px             | 7.5px     | 14px        | 42px       |
| Round 1   | 10px            | 9px       | 16px        | 52px       |
| Round 2   | 11px            | 10px      | 18px        | 57px       |
| Quote      | 11px → 13px    | subtitle 9→10px | —       | —          |

Key rule: **if the box looks empty, enlarge until it's filled.** A box where content occupies <60% of the vertical space will draw a "太空了" correction.

## Cell Height Scaling (Multiplier → Exact Pattern)

When user says "XX行高度*N", start with multipliers but expect the user to replace them with exact values later. The final settled heights from iterative refinement:

| Row | Final Height | Rationale |
|-----|-------------|-----------|
| 系统与工具 | 85px | Tags + 2 text lines fill comfortably |
| AI应用场景 | 85px | Same as above |
| 组织形态 | 90px | 1 tag + 3 text lines needs more room |
| 老板行动 | 80px | Title + 2 lines, less content |
| 关键风险 | 85px | 1 tag + 2 risk lines, compact |
| 六层→三层 | 55px | 6 pills + 3 investment bars |

- Summary cards height multiplier: ×1.1 (e.g., 108→118px) when user specifies
- Compress headers, maturity, business-value, CEO, enterprise-apps rows to compensate for taller grid rows
- All content stays inside 1920×1080 viewBox
- After user provides exact heights, use those — don't override with multiplier calculations
- **Font scaling for bottom rows**: when user says "加大30%" on value-chain / six-layer / CEO / enterprise-app rows, scale tag fonts proportionally: 8px→10px, 8.5px→11px, 9px→12px. Apply to ALL text in the target rows, not just pills — section titles, bar labels, and CEO items included.

## Layout Preference: Left-Aligned with Equal Line Spacing (Final State)

After many iterations, the final settled layout is:
- **Tags**: left-aligned (`text-anchor="start"`), grouped near cell top
- **Text**: left-aligned with **equal line spacing (20px)** throughout all grid rows
- Vertical centering: content block centered within the cell height
- Sidebar label boxes: title at **14px**, subtitle at **10px**, filling ~80% of label box height

**Centered layout (default):**
- Tags grouped on one row near cell top, centered on column center-x
- Gap of ~20px (one empty line) between tags and text
- Text lines at `text-anchor="middle"` with x = column center
- 3 text lines at 10px font, ~18-20px line spacing
- All cells in a row use identical Y offsets

**Left-aligned layout (user may request):**
- Tags: `text-anchor="start"` at x = cell_x + 12
- Text: `text-anchor="start"` at x = cell_x + 20
- Equal line spacing: exactly 20px between all text baselines
- Tag row y = cell_y + 10; first text line y = tag_bottom + 22px
- Example for 85px cell: tags at y = cell_y + 10, text at y = cell_y + 45 and y = cell_y + 65

**Horizontal layout ("标签左, 内容右") — experimental, user often reverts:**
- Tags must be compressed (13-15px, tight 3px gaps) to fit 3-4 tags in left column
- If 2+ tags overflow the cell, immediately revert to centered
- The user will say "回退到标签居中" or "标签和内容都居中" — do not resist

**Sidebar label box sizing:**
- Title font: **14px** font-weight="700" (NOT 10px — box feels empty)
- Subtitle font: **10px** (NOT 7px — unreadable at that size)
- Content should fill ~70-80% of the label box vertically
- For 85px tall label: title at cell_y + 30, subtitle at cell_y + 55

## Left Sidebar Label Standardization

The left sidebar (row titles + subtitles column, typically x=20, width=130) must use uniform sizes across ALL rows — mixing different font sizes on different rows looks sloppy and will draw a correction.

- **Title text:** 14px, font-weight="700", fill="#0F172A"
- **Subtitle text:** 10px, font-weight="400", fill="#64748B"
- Title y-position: ~34px from row top (centered within the row box)
- Subtitle y-position: ~58px from row top (below title, 24px gap)
- This applies to every row with a text label, not just the first few
- If a row is too short (e.g., 20px separator), skip the subtitle entirely — keep only the title, still at 14px

When the user says "左侧标题字体统一下" or "所有左侧标题统一14px", this means EVERY label — system rows, stage labels, summary cards, CEO rows, enterprise apps — gets the same 14px/10px treatment. Don't try to use 13px or 12px for shorter rows.

## Version Management

When iterating on a diagram, create separate files rather than overwriting:
- V1: original content (no fusion)
- V2: content fusion attempt
- V3: refined fusion
- User will ask to sync changes across all versions — apply the same fixes to each file
- Each version file holds its own complete inline SVG (no shared references)
- **DO NOT** patch V1 to match V3 style iteratively — the two versions have different row counts and heights, so patch-based sync will corrupt V1. Instead, regenerate V1 from scratch using the same Python generator but with V1-specific content (no value chain, 六层, CEO, or enterprise app rows). V1 gets taller individual rows since it has fewer total rows within the same 1080px height.

## Batch Centering Fix (Python)

When you need to fix text-anchor and x-coordinates across many elements (e.g., reverting from horizontal layout to centered), use a Python regex pass rather than editing line by line:

```python
import re
content = open('file.html').read()
# Add text-anchor="middle" to <text> elements that match a column center x
content = re.sub(r'(<text\s+x="(?:373|808|1243|1683)"[^>]*?)(?<!"middle")>', r'\1 text-anchor="middle">', content)
# Fix x to column center for all content text lines
content = re.sub(r'(<text\s+x=")\d{3,4}("[^>]*class="text"[^>]*>)', r'\g<1>373\g<2>', content)  # adjust per column
open('file.html','w').write(content)
```

Column centers for 4-stage layout (L0/L1/L2/L3): 373, 808, 1243, 1683

## Full SVG Regeneration with Python (Use After 3+ Iterations)

When tags are disconnected from containers, text overlaps, or x-coordinates leak into the sidebar, **DO NOT PATCH** — regenerate the entire SVG from a Python script. This is the ONLY reliable way to produce consistent coordinates.

### When to use this:
- User says "标签与框体已经完全脱节"
- User says "请用设计规范进行全面校验" or "给我重构整个版本"
- After 3+ rounds of iterative patches result in visible layout breakage
- When `text-anchor` mismatches cause overlapping text

### Core Functions

```python
FONT = "'PingFang SC','Microsoft YaHei',sans-serif"
W, H = 1920, 1080
# Column centers MUST match cell rects exactly
COLS = {
    'L0': {'x': 160, 'w': 425, 'cx': 373},
    'L1': {'x': 595, 'w': 425, 'cx': 808},
    'L2': {'x': 1030, 'w': 425, 'cx': 1243},
    'L3': {'x': 1465, 'w': 435, 'cx': 1683},
}
COLS_LIST = ['L0', 'L1', 'L2', 'L3']
SIDEBAR_X = 85  # center of sidebar (box 20-150)

# Stage colors (used for cell borders and backgrounds)
SC = {
    'L0': {'border': '#94A3B8', 'fill': '#F8FAFC', 'text': '#64748B', 'accent': '#94A3B8'},
    'L1': {'border': '#3B5BDB', 'fill': '#EFF6FF', 'text': '#1F3A8A', 'accent': '#3B5BDB'},
    'L2': {'border': '#7C3AED', 'fill': '#EEF2FF', 'text': '#4F46E5', 'accent': '#7C3AED'},
    'L3': {'border': '#06B6D4', 'fill': '#ECFEFF', 'text': '#0E7490', 'accent': '#06B6D4'},
}

def tag_rect(x, y, w, h, fill, stroke, text, color, fs=9, fw=600):
    """Tag pill with centered text — text x = rect center"""
    cx = x + w/2
    cy = y + h/2 + fs/3
    return f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="4" fill="{fill}" stroke="{stroke}" stroke-width=".5"/><text x="{cx:.0f}" y="{cy:.0f}" fill="{color}" font-size="{fs}" font-weight="{fw}" text-anchor="middle" font-family="{FONT}">{text}</text>'

def center_tags(tags, cell_cx, y, gap=6):
    """Group tags centered on cell_cx. tags: [(width, fill, stroke, text, color), ...]"""
    total_w = sum(t[0] for t in tags) + (len(tags)-1)*gap
    x_start = cell_cx - total_w/2
    parts = []
    for i, (w, fill, stroke, text, color) in enumerate(tags):
        x = x_start + sum(t[0] for t in tags[:i]) + i*gap
        parts.append(tag_rect(x, y, w, 16, fill, stroke, text, color))
    return ''.join(parts)

def cell_bg(x, w, y, h, stage, extra_border=None):
    """Cell background rect with stage-colored top border"""
    b = extra_border or SC[stage]['accent']
    return f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="8" fill="#fff" stroke="#E2E8F0" stroke-width="1"/><rect x="{x}" y="{y}" width="{w}" height="{h}" rx="8" fill="none" stroke="{b}" stroke-width="2"/>'

def sidebar(y, h, title, subtitle='', color='#0F172A', title_fs=14, sub_fs=10):
    """Sidebar label box — title 14px, subtitle 10px, centered in box"""
    cy = y + h/2
    parts = f'<rect x="20" y="{y}" width="130" height="{h}" rx="8" fill="#fff" stroke="#E2E8F0" stroke-width="1"/>'
    if subtitle:
        parts += f'<text x="{SIDEBAR_X}" y="{cy-3:.0f}" fill="{color}" font-size="{title_fs}" font-weight="700" text-anchor="middle" font-family="{FONT}">{title}</text>'
        parts += f'<text x="{SIDEBAR_X}" y="{cy+18:.0f}" fill="#64748B" font-size="{sub_fs}" text-anchor="middle" font-family="{FONT}">{subtitle}</text>'
    else:
        parts += f'<text x="{SIDEBAR_X}" y="{cy+5:.0f}" fill="{color}" font-size="{title_fs}" font-weight="700" text-anchor="middle" font-family="{FONT}">{title}</text>'
    return parts

def text_line(x, y, content, color='#475569', fs=10, fw=400):
    """Centered text line at column center"""
    return f'<text x="{x}" y="{y}" fill="{color}" font-size="{fs}" font-weight="{fw}" text-anchor="middle" font-family="{FONT}">{content}</text>'
```

### Y-Layout Planning (MUST plan before writing any SVG)

Sketch the full page top-to-bottom, allocating y and height for every row:

| Row | y | h | Notes |
|-----|---|---|-------|
| Header | 0 | 36 | Title bar |
| Stage headers | 40 | 54 | L0-L3 labels + arrows |
| 数字化成熟度 | 98 | 38 | Gradient bar |
| 系统与工具 | 140 | 85 | Tags + layer label + 2 text |
| AI应用场景 | 229 | 85 | Tags + badges + 2 text |
| 组织形态 | 318 | 90 | Tag + 3 text lines |
| 老板行动 | 412 | 80 | Amber bg, diamond ◆ |
| 关键风险 | 496 | 85 | Red bg, ⚠ warnings |
| 业务价值 | 585 | 34 | Green gradient |
| 价值链 | 623 | 46 | HQ/SC/SR three blocks |
| 六层→三层 | 673 | 55 | L6-L1 pills + 3 bars |
| CEO三件事 | 732 | 28 | 3 items |
| 企业应用 | 768 | 36 | 14 pills |
| Quote | 810 | 14 | Italic quote |
| Cards | 824 | 116 | 2 summary cards |
| Legend | 946 | 26 | Swatches + labels |
| Footer | 978 | 30 | Meta |
| **Total** | | ~1008 | 72px margin |

4px gap between every row. Adjust row heights proportionally if content changes.

### Row Generation Pattern

For each matrix row (4 cells × 4 stages), use this pattern:

```python
y = 140; h = 85
parts.append(sidebar(y, h, '🏗️ 系统与工具', 'L1→L6分层覆盖'))

sys_tags = [
    [('收银', '#F1F5F9', '#CBD5E1', '#64748B'), ('基础通讯', '#F1F5F9', '#CBD5E1', '#64748B')],
    [('CRM', '#EFF6FF', '#BFDBFE', '#1D4ED8'), ('财务', '#EFF6FF', '#BFDBFE', '#1D4ED8'), ('协同', '#EFF6FF', '#BFDBFE', '#1D4ED8')],
    # ... etc for all 4 stages
]

for i, stage in enumerate(COLS_LIST):
    c = COLS[stage]
    parts.append(cell_bg(c['x'], c['w'], y, h, stage))
    # Tags: each tag is (text, fill, stroke, color). Width = len(text)*14 for Chinese
    tinfos = [(len(t[0])*14-2, t[1], t[2], t[0], t[3]) for t in sys_tags[i]]
    parts.append(center_tags(tinfos, c['cx'], y+10))
    # Text lines at column center
    parts.append(text_line(c['cx'], y+58, '· Content line 1', '#475569', 9.5))
    parts.append(text_line(c['cx'], y+76, '▸ Action line', '#3B5BDB', 9.5))
```

Tag width estimation: `len(text)*14` for Chinese (14px per char at 9px font), `len(text)*10` for English/mixed. Subtract 2px for padding. Fine-tune after generation if tags look loose or cramped.

### Key principles
1. Every `<text>` uses `text-anchor="middle"` with x at the exact center of its container rect
2. Calculate, don't guess — all x/y from column centers, not hardcoded
3. Sidebar labels always at x=85 (center of 20-150 box)
4. Assemble with `'\n'.join(parts)` — one part per SVG element
5. Row heights pre-planned top-to-bottom before writing any SVG, ensuring total ≤1080
6. When user says "标签左对齐", check if existing tags are already `text-anchor="middle"` — it may be a display artifact, not a real alignment issue. Layer labels or other sub-elements positioned left-of-center in a cell can look left-aligned even when they're centered on their own rect. Center them on the cell center instead.

### Verification (run after generation)
```bash
grep -c 'text-anchor="start"' file.html  # must be 0
grep -oP '<text x="(\d+)"' file.html | awk -F'"' '$2<160 && $2>86' | wc -l  # must be 0 (sidebar zone clear)
grep 'x="85".*font-size' file.html | grep -v 'font-size="14"' | grep -v 'font-size="10"'  # must be empty
```

## Legend Row Centering

When regenerating the legend row (swatches + labels in a 1880px bar at x=20):

1. List all legend items with estimated text widths (Chinese chars ~10px each at 10px font)
2. Calculate total width: sum(swatch 18 + gap 6 + text_width + margin 20) for each item, plus description text
3. Compute `shift = (1880 - start_x_last_item + desc_width) / 2` to center the group
4. Apply shift to ALL x coordinates in the legend row
5. Verify: `grep -n 'y="96[0-9]"' file.html` and check items span ±400px from bar center (x=960)
6. Remove any stale legend lines from previous edits (duplicates at old x positions)

## Bar Width Fine-Tuning (底座/中枢/前台)

When three bars sit in a 1740px content row, the user may iterate through:
- **Equal-width**: `each = (1740 - 2*gap) / 3`, spaced evenly across the row
- **Shorten N%**: multiply each width by `(1 - N/100)`, readjust positions
- **Left-aligned**: place bars sequentially with small (4px) gaps: `x_next = x_prev + w_prev + gap`
- **Enlarge N%**: multiply each width by `(1 + N/100)`, keep 4px gaps

After EVERY width change, re-calculate text centers as `x + w/2`. Verify: `grep 'y="699"' file.html && grep 'y="711"' file.html`

## Layer Labels That Appear Left-Aligned

Small sub-element labels (like "L1硬件层", "L2+L6层") inside content cells may be centered on their own tiny rect (e.g., `x=170, w=60, text at x=200`) but appear visually left-aligned within the cell. The user will say "还有左对齐的标签" even though `text-anchor="middle"` is set.

**Fix**: Center the rect on the cell center: `rect_x = cell_cx - rect_w/2`, `text_x = cell_cx`. This positions both rect and text at the column center rather than near the cell left edge.

## Equal-Width Pill Distribution

When user asks for "水平均宽" or the pills look uneven:
- For the 六层 row: divide 1740px available width equally among 6 layers (283px each, 8px gaps)
- For the 企业应用 row: divide equally among all pills (~120px each for 14 pills)
- Base formula: `pill_width = (available_width - (n-1)*gap) / n`
- Available width for L1-L6 pills: 1740px - 5*8px = 1700px, each = 283px
- Available width for enterprise pills: 1740px - 13*4px = 1688px, each = 120px
- The last pill may be slightly narrower if total doesn't divide evenly

## Content Fusion from External Documents

When the user provides a Feishu file link to merge into a diagram:
1. Try `curl` to download — if it returns HTML (login page), the file requires auth
2. Ask the user to send the document directly (download and attach, or screenshot)
3. Once content arrives as HTML, search for slide/page markers (`slide-num`, `data-title`)
4. Extract core content (not raw HTML — distill to key concepts, metrics, structure)
5. Merge organically: add new rows below the existing grid, label the source

## Fitting More Content into 16:9

When adding new sections to a diagram that already fills 1920×1080:
- Compress grid rows from 68→60px (saves ~40px across 5 rows)
- Compress continuous rows from 50→44px
- Replace verbose summary cards with compact inline sections
- Use the freed vertical space for new content rows
- New rows go below the existing grid, before the legend/footer zone
