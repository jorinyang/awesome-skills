# Chinese Business Diagram — Quick Reference

## Palette

| Hex | Role |
|-----|------|
| `#FAFBFD` | Page background |
| `#FFFFFF` | Card/SVG background |
| `#0F172A` | Primary text |
| `#475569` | Secondary text |
| `#64748B` | Muted labels |
| `#94A3B8` | Metadata, hints |
| `#1F3A8A` | Blue — L1 stage, strong labels |
| `#3B5BDB` | Blue — annotations, key actions ▸ |
| `#1D4ED8` | Blue — tags (system/CRM) |
| `#DC2626` | Red — ⚠ risk, emphasis, deadlines |
| `#B91C1C` | Red — tag pill text |
| `#15803D` | Green — business value |
| `#10B981` | Green — growth metrics |
| `#92400E` | Amber — boss action text |
| `#FDE68A` | Amber — boss cell border |
| `#FFFDF5` | Amber — boss cell background |
| `#4F46E5` | Purple — L2 stage |
| `#7C3AED` | Purple — L2 border |
| `#6D28D9` | Purple — L2 tag |
| `#0E7490` | Cyan — L3 stage |
| `#06B6D4` | Cyan — L3 border, AI-native |
| `#FEF2F2` | Red — risk cell background |
| `#FECACA` | Red — risk cell border |

## Font Stack

```
"PingFang SC", "HarmonyOS Sans SC", "Source Han Sans SC", "Microsoft YaHei", sans-serif
```

## Stage Colors (L0→L3)

| Stage | Border | Header Fill | Text |
|-------|--------|-------------|------|
| L0 空白期 | `#94A3B8` | `#F8FAFC` | `#64748B` |
| L1 起步期 | `#3B5BDB` | `#EFF6FF` | `#1F3A8A` |
| L2 深化期 | `#7C3AED` | `#EEF2FF` | `#4F46E5` |
| L3 AI原生 | `#06B6D4` | `#ECFEFF` | `#0E7490` |

## Cell Patterns

- 10px border radius
- Top border accent: 2px matching stage color
- Tag pills inside cells: 5px radius, light fill
- Risk cells: `#FFF5F5` bg, `#FECACA` border, red text
- Boss cells: `#FFFDF5` bg, `#FDE68A` border, amber text
- Value band: `#F0FDF4` bg, green gradient bar
