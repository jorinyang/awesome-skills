# Engineering Blueprint Theme — Dark Navy Variant

When the user asks for "工程蓝图风格" (engineering blueprint style), switch from the light Chinese business theme to this dark navy variant. It mimics architectural/engineering cyanotype drawings with grid backgrounds, white/cyan lines, and high-contrast text.

## Trigger
- User says "工程蓝图" / "blueprint风格" / "工程图纸"
- User wants "远看有结构，近看有细节"
- User describes "专业" + dark background + high contrast

## Color System

| Role | Color | Usage |
|------|-------|-------|
| Page background | `#0A1628` | Deep navy (cyanotype paper) |
| Grid lines (fine) | `#132238` | 40px grid, 0.4px stroke |
| Grid lines (major) | `#132238` | 160px major grid, 0.8px stroke |
| Panel/card bg | `#0F1D30` | Slightly lighter than page |
| Cell interior | `#0D1B2E` | Content cells |
| Cell alternate | `#111F35` | Sidebar/header cells |
| Header bar | `#0C1A2C` | Top header |
| Default border | `#1E3A5F` | Subtle borders |
| Bright border | `#3A6B9F` | Accent borders, outer frame |
| Primary text | `#E8F0FE` | Titles, headings (near-white) |
| Body text | `#B8CCE4` | Content lines |
| Secondary text | `#7B93AD` | Descriptions |
| Muted text | `#566D85` | Metadata, legend |

### Stage Colors (adapted for dark bg)
| Stage | Border | Fill | Text | Accent |
|-------|--------|------|------|--------|
| L0 | `#5A7088` | `#141F2E` | `#8DA0B5` | `#5A7088` |
| L1 | `#0098C7` | `#0F2232` | `#40B8DC` | `#0098C7` |
| L2 | `#6B80F0` | `#121E35` | `#98A8F8` | `#6B80F0` |
| L3 | `#00C8E0` | `#0B2632` | `#40D8EC` | `#00C8E0` |

### Functional Colors
| Role | Color | Usage |
|------|-------|-------|
| Risk bg | `rgba(255,90,90,0.06)` | Risk row cells |
| Risk border | `#FF5A5A` | Risk row borders, ⚠ tags |
| Risk text | `#FF8080` | Risk text, warnings |
| Boss bg | `rgba(255,200,50,0.06)` | Boss row cells |
| Boss border | `#E8B830` | Boss row borders |
| Boss text | `#F0CC60` | Boss row text, ◆ symbols |
| Value bg | `rgba(60,200,180,0.06)` | Value row |
| Value border | `#3CC8B4` | Green accents |
| Blue annotation | `#40B8E0` | ▸ actions, L1 stage |
| Red emphasis | `#FF6B6B` | ⚠ risks, deadlines |
| Purple | `#8898F8` | L2 stage, advanced |
| Cyan | `#40D8F0` | L3 stage, cutting-edge |
| Amber | `#F0C840` | Boss/leader emphasis |

### Tag Fill/Stroke Colors
| Tag Type | Fill | Stroke | Text |
|----------|------|--------|------|
| L0 tags | `#1A2838` | `#3A5068` | `#8DA0B5` |
| L1 tags | `#0D2838` | `#106080` | `#40B8DC` |
| L2 tags | `#142038` | `#384898` | `#98A8F8` |
| L3 tags | `#0B3038` | `#107080` | `#40D8EC` |
| AI tags | `#0D2838` | `#106080` | `#40B8DC` |
| Risk tags | `#281818` | `#683838` | `#FF8080` |
| Boss tags | `#201810` | `#685030` | `#F0C840` |

## Grid Pattern (CRITICAL for blueprint feel)

```svg
<defs>
  <pattern id="g" width="40" height="40" patternUnits="userSpaceOnUse">
    <path d="M40 0L0 0 0 40" fill="none" stroke="#132238" stroke-width=".4"/>
  </pattern>
  <pattern id="gm" width="160" height="160" patternUnits="userSpaceOnUse">
    <rect width="160" height="160" fill="url(#g)"/>
    <path d="M160 0L0 0 0 160" fill="none" stroke="#132238" stroke-width=".8"/>
  </pattern>
</defs>

<rect width="1920" height="1080" fill="#0A1628"/>
<rect width="1920" height="1080" fill="url(#gm)" opacity="0.6"/>
```

## Outer Frame with Corner Ticks

```svg
<rect x="8" y="8" width="1904" height="1064" rx="4" fill="none" stroke="#3A6B9F" stroke-width="1.5" opacity="0.5"/>
<!-- 4 corner ticks -->
<line x1="8" y1="20" x2="8" y2="8" stroke="#3A6B9F" stroke-width="2" opacity="0.7"/>
<line x1="20" y1="8" x2="8" y2="8" stroke="#3A6B9F" stroke-width="2" opacity="0.7"/>
<!-- Repeat for (1912,8), (8,1072), (1912,1072) -->
```

## Cell Background (double-layer for dark bg)

```python
def cell_bg(x, w, y, h, stage):
    s = BP[stage]
    return (
        f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="6" fill="{BP["cell"]}" stroke="{BP["border"]}" stroke-width="1"/>'
        f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="6" fill="none" stroke="{s["border"]}" stroke-width="2"/>'
    )
```

## Header Styling

```svg
<text x="1850" y="24" fill="#566D85" font-size="8" text-anchor="end">REV.4 · 2026-06</text>
```

## Verification

```bash
grep -c 'text-anchor="start"' file.html         # must be 0
grep 'pattern id="g"' file.html                  # fine grid exists
grep 'fill="url(#gm)"' file.html                 # grid applied
grep -c 'fill="#FFFFFF"' file.html               # should be 0
```
