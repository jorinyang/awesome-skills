# Chinese Promotional Event Poster Patterns

## When to use this reference
When the user asks for promotional posters for Chinese events, activities, carnivals, sales, or campaigns aimed at social media sharing (微信朋友圈, 小红书, 抖音).

## Format
- **Size**: 1080×1920px (9:16 portrait) — standard for social media stories/posts
- **Type**: Single self-contained HTML file per poster variant
- **Font stack**: `'PingFang SC', 'Noto Sans SC', 'Microsoft YaHei', sans-serif` (for modern look) or `'PingFang SC', 'Noto Serif SC', 'SimSun', 'STSong', serif` (for traditional/Chinese aesthetic)

## Background: Photo-first principle (MANDATORY)

> ⚠️ **The background IS the poster.** Pure gradients, abstract SVGs, and geometric decorations look fake and AI-generated ("太人机感"). Real landscape photographs are strongly preferred.

**Preferred approach**: Full-bleed landscape photo as CSS `background-image` covering the entire 1080×1920 canvas. Photo sources (priority order):
1. User-supplied real photos of the location (best — maximum authenticity)
2. ComfyUI / AI-generated realistic landscape photos matching the venue description
3. Free stock photos (Unsplash, Pexels, Pixabay) — use `images.unsplash.com/photo-{ID}?w=1080&h=1920&fit=crop` pattern

**Fallback ONLY when no photo is available**: Gradient + minimal SVG decoration (the original 5-style palette below). Always ask the user first: "你有实拍照片吗？"

**Photo-to-text ratio**: ~75% photo / 25% text overlay. The photo does the emotional selling; text handles the information.

**Multi-poster variation with one photo**: When you have only one photo for N posters, crop N different 1080×1920 regions from it using PIL:
```python
from PIL import Image
img = Image.open("photo.jpg")
w, h = img.size
margin = w - 1080
for i in range(5):
    offset = int(margin * i / 4)  # spread evenly across width
    crop = img.crop((offset, 0, offset + 1080, 1920))
    crop.save(f"bg-0{i+1}.jpg", quality=92)
```

## Text-on-photo readability (the "Stroke" technique)

When text sits directly on a busy photo background, do NOT use semi-transparent card overlays (glassmorphism) — they block the photo and feel artificial. Instead:

- **Text stroke (outline)**: `-webkit-text-stroke: 2px rgba(0,0,0,0.5)` on white text, or `filter: drop-shadow(0 2px 0 rgba(255,255,255,0.4))` on gradient-clipped text. This keeps the photo fully visible while making text "pop."
- **Drop shadow backup**: `text-shadow: 0 2px 12px rgba(0,0,0,0.6)` on all overlaid text.
- **Bottom info area**: Use a `linear-gradient(transparent, rgba(0,0,0,0.6))` overlay strip at the bottom ~25% for logistics text — creates a natural dark anchor without hard card edges.
- **Color coordination**: Pick text accent colors from the photo itself (e.g., orange text matches orange life vests in the photo). Creates cohesion without blocking the image.
- **Title treatment**: Gradient text-clip (orange→gold) + `drop-shadow` for the white "stroke" effect + `text-shadow` for dark depth. Example:
```css
.title {
  background: linear-gradient(180deg, #ff8c42, #ffd166);
  -webkit-background-clip: text; -webkit-text-fill-color: transparent;
  filter: drop-shadow(0 3px 0 rgba(255,255,255,0.5)) drop-shadow(0 6px 12px rgba(0,0,0,0.4));
}
```

## Canonical layout structure (top → bottom)

```
┌─────────────────────────┐
│  Visual Badge / Tag     │  ← Small label: "周末嘉年华", "SUMMER · FUN", seal stamp
│                         │
│  TITLE (bold, 72-82px)  │  ← Event name with keyword highlight
│  Subtitle / English     │  ← Optional: SUP CARNIVAL, date range
│                         │
│  ┌─────────────────┐    │
│  │   ¥120 / 人      │    │  ← Price: prominent, visually distinct
│  │   统一价·无额外   │    │     (badge, card, scroll, hex shape)
│  └─────────────────┘    │
│                         │
│  ✔ Feature 1  ✔ Feature 2│
│  ✔ Feature 3  ✔ Feature 4│  ← 2-column grid, checkmark/dot markers
│  ✔ Feature 5  ✔ Feature 6│
│                         │
│  Slogan / tagline       │  ← Descriptive one-liner about the venue
│  ⏰ Time info           │
│  📍 Location            │
│  4-60岁 | 报名方式      │  ← Footer: age range + registration
└─────────────────────────┘
```

## Background: Photo-first principle (MANDATORY)

> ⚠️ **The background IS the poster.** Pure gradients, abstract SVGs, and geometric decorations look fake and AI-generated ("太人机感"). Real landscape photographs are strongly preferred.

**Preferred approach**: Full-bleed landscape photo as CSS `background-image` covering the entire 1080×1920 canvas. Photo sources (priority order):
1. User-supplied real photos of the location (best — maximum authenticity)
2. ComfyUI / AI-generated realistic landscape photos matching the venue description
3. Free stock photos (Unsplash, Pexels, Pixabay) — use `images.unsplash.com/photo-{ID}?w=1080&h=1920&fit=crop` pattern

**Fallback ONLY when no photo is available**: Gradient + minimal SVG decoration (the original 5-style palette below). Always ask the user first: "你有基地实拍照片吗？"

**Photo-to-text ratio**: ~75% photo / 25% text overlay. The photo does the emotional selling; text handles the information.

## Text-on-photo readability (the "Stroke" technique)

When text sits directly on a busy photo background, do NOT use semi-transparent card overlays (glassmorphism) — they block the photo and feel artificial. Instead:

- **Thick text stroke (outline)**: White text gets a dark stroke (`-webkit-text-stroke: 3px rgba(0,0,0,0.5)`), dark text gets a white stroke. This keeps the photo fully visible while making text "pop."
- **Drop shadow backup**: `text-shadow: 0 2px 12px rgba(0,0,0,0.6)` on all overlaid text.
- **Bottom info area**: Use a `linear-gradient(transparent, rgba(0,0,0,0.6))` overlay strip at the bottom ~25% for logistics text — creates a natural dark anchor without hard card edges.
- **Color coordination**: Pick text accent colors from the photo itself (e.g., orange text matches orange life vests visible in the photo). Creates visual cohesion without blocking the image.

## Z-pattern layout (over photo)

```
┌─────────────────────────┐
│  TAG (top-left/right)   │  ← Small label over sky/negative space
│                         │
│  MAIN TITLE             │  ← Large bold text with stroke, positioned
│  subtitle / English      │     over the upper third of photo (sky area)
│                         │
│  ┌─── PRICE ───┐        │  ← Prominent badge, stroke outline
│  └──────────────┘        │
│                         │
│  Feature 1    Feature 2  │  ← 2-column text placed in photo's negative
│  Feature 3    Feature 4  │     space (water area, sky gaps) — never
│  Feature 5    Feature 6  │     overlap the main subject (people, focal point)
│                         │
│  ── dark gradient ──    │  ← Gradual overlay for readability
│  Slogan · Time · Location│
│  Age range · CTA         │
└─────────────────────────┘
```

## 5-style variant palette (FALLBACK — only when no photo available)

Gradient-based styles. **Prefer photo backgrounds over these.** Use only when user has no photos and image generation isn't available:

| # | Style | Palette | Vibe | Decorative element |
|---|-------|---------|------|--------------------|
| 1 | **夏日活力** | Orange/gold gradient (#ff6b35→#ffb347) | Energetic, youthful | Sun burst, wave SVG, glassmorphism badge |
| 2 | **清凉水岸** | Blue gradient (#0077b6→#caf0f8) | Refreshing, calm | Ripple circles, mountain silhouette SVG, light rays |
| 3 | **极限运动** | Black + neon cyan (#00f5d4) | Sporty, bold | Diagonal stripes, corner borders, hexagonal price |
| 4 | **自然山野** | Green gradient (#2d5016→#a8d45a) | Earthy, organic | Tree silhouettes, mist layers, wood-texture price |
| 5 | **国潮嘉年华** | Chinese red + gold (#c41e3a + #ffd700) | Traditional, celebratory | Lantern glows, gold border frame, seal stamp |

## Key techniques
- **Price display**: Always visually dominant — use large font (80-90px), contrasting treatment. On photos: white text with dark stroke. On gradients: contrasting background shape.
- **Feature grid**: 2-column, compact, checkmark/dot/diamond marker. On photos: bare text with stroke, placed in negative space. On gradients: semi-transparent card backgrounds (rgba white 0.15-0.2 + backdrop-filter blur).
- **Bottom info**: Gradient overlay (transparent → dark) to anchor text at bottom, with time/location/CTA. Works on both photos and gradient backgrounds.
- **No external dependencies**: All CSS inline, no Google Fonts, no JS frameworks — each file is fully portable
- **Name files**: `poster-0N-descriptive-slug.html` for easy identification

## Pitfalls

- ❌ **Do NOT default to gradient backgrounds without first offering the photo option.** Ask the user "你有实拍照片吗？" or offer to generate with ComfyUI. Gradients-only posters look "假" and "太人机感" (fake, AI-generated feel).
- ❌ **Do NOT use glassmorphism cards over photo backgrounds** — text stroke outlines + drop shadows are the correct technique for photo backgrounds. Cards block the image and defeat the purpose.
- ❌ **Do NOT place text over the photo's main subject (people, focal point)** — use negative space (sky, water, dark areas).
- ❌ **Do NOT claim ComfyUI is available without first running `hardware_check.py`** — WSL without GPU passthrough, CPU-only machines, and free-tier Cloud accounts will fail silently. Check first, fall back to photo-cropping or stock images.
- ❌ Don't make posters responsive — 1080×1920 is the fixed deliverable, body centers it in viewport
- ❌ Don't use `position: fixed` — use `position: absolute` within the poster container
- ❌ Don't use stock-photo placeholders — abstract geometric/texture decoration is cleaner (when no photo)
- Chinese text at 72-82px for titles is readable at mobile screen sizes when viewing the full poster
- Verify in browser by opening file directly — no server needed
- Screenshot to PNG via Playwright with `element.screenshot()` at 1125×2001 viewport (3x mobile)
- `file://` URLs in CSS `background-image` must use absolute paths (`file:///home/...`) for Playwright to resolve them
