# Reading Picture-Based Feishu Slides

> 2026-06-02: Discovered while analyzing `Zhi_Ke_Digital_Survival_Kit` slides.

## Problem

`lark-cli docs +fetch` only supports `docx` type. When a Wiki document is `slides` type and each slide is a PICTURE (not text), there is no direct CLI path to extract its content.

## Workflow

### Step 1: Resolve Wiki token → obj_token

```bash
lark-cli wiki +node-get --node-token https://acn3kz7weyc0.feishu.cn/wiki/<WIKI_TOKEN> --as bot --format json
```

Extract `obj_token` and `obj_type` from the response. For slides, `obj_type` will be `"slides"`.

### Step 2: Export as PPTX

```bash
lark-cli drive +export \
  --token <OBJ_TOKEN> \
  --doc-type slides \
  --file-extension pptx \
  --file-name output.pptx \
  --output-dir . \
  --overwrite \
  --as bot
```

> ⚠️ `--output-dir` must be a relative path. Set `--output-dir .` and `cd` first. On failure, the export artifact is already ready — use the hint to retry with `+export-download`.

### Step 3: Extract images from PPTX

The PPTX is a ZIP file. All slides are stored as `ppt/media/imageN.png`:

```python
import zipfile, os

os.makedirs('/tmp/slides', exist_ok=True)
with zipfile.ZipFile('output.pptx', 'r') as z:
    for f in z.namelist():
        if f.startswith('ppt/media/image'):
            z.extract(f, '/tmp/slides/')
```

If `unzip` is not available on the system, use Python's `zipfile` module (stdlib, no deps).

### Step 4: Analyze each image with vision

```python
# Use minimax understand_image for each slide
for i in range(1, total_slides + 1):
    image_path = f'/tmp/slides/ppt/media/image{i}.png'
    # Call: mcp_minimax_mcp_understand_image(
    #   image_source=image_path,
    #   prompt="Extract ALL text content from this slide..."
    # )
```

**Prompt template:**
> "Extract ALL text content from this slide. Read every heading, bullet point, table cell, and any other text. This is a presentation slide — extract every piece of information."

### Step 5: Compile results

Process vision results in parallel batches (3-4 at a time) to reduce latency. Assemble a structured summary from all slide analyses.

## Pitfalls

1. **`python-pptx` won't help**: If all slides are PICTURE type, `pptx` library returns empty text frames. Don't waste time — go straight to zip extraction + vision analysis.
2. **`feishu_doc_read` tool**: Returns "Feishu client not available" unless invoked from a Feishu comment context. Not useful for slides.
3. **`browser_navigate`**: May fail if Node.js is unavailable in the environment. CLI export is more reliable.
4. **Token types**: Wiki URLs use wiki tokens (`UOd9...`), but `drive +export` needs the underlying `obj_token` (`VaRm...`). Always resolve via `wiki +node-get` first.
5. **Export failure**: If `+export` fails with "file token invalid" (1069914), it means you're using the wiki token instead of the obj_token. Resolve first.
