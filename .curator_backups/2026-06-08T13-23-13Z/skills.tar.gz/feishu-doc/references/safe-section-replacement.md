# Safe Wiki Doc Section Replacement Pattern

When replacing a large section of an existing Feishu wiki doc that contains embedded images in OTHER sections.

## When to Use

- Updating one h1 section without touching other sections
- Other sections contain Feishu-internal `<img src="...">` tags (instructor photos, diagrams)
- `str_replace` fails because pattern/content strings exceed CLI argument limits

## Workflow

```python
from hermes_tools import terminal
import json, re

# 1. Fetch current full doc
result = terminal("lark-cli docs +fetch --api-version v2 --doc DOC_TOKEN --as bot 2>&1")
lines = result["output"].split("\n")
start = next(i for i, l in enumerate(lines) if l.strip().startswith("{"))
data = json.loads("\n".join(lines[start:]))
full = data["data"]["document"]["content"]

# 2. Split at section boundaries
section_start_marker = '<h1>SECTION_TO_REPLACE</h1>'
next_section_marker = '<h1>NEXT_SECTION_AFTER</h1>'

idx_start = full.index(section_start_marker)
idx_next = full.index(next_section_marker, idx_start)

before = full[:idx_start]
after = full[idx_next:]

# 3. CRITICAL: Strip Feishu-internal <img> tags from "after" section
# These have src="DfdjbqxhJo..." tokens that cause degrade_code=3001
after_clean = re.sub(
    r'<img [^>]*src="[^"]*"[^>]*/>',
    '<p><em>（照片需手动重新上传）</em></p>',
    after
)

# 4. Combine with new section content
new_section = """<h1>SECTION_TO_REPLACE</h1>
<p>New content here...</p>"""

full_new = before + new_section + after_clean

# 5. Write and overwrite
with open("/tmp/update.xml", "w") as f:
    f.write(full_new)

result = terminal(
    "cd /tmp && lark-cli docs +update --api-version v2 "
    "--doc DOC_TOKEN --command overwrite --content @update.xml --as bot 2>&1"
)
data = json.loads(result["output"])
warnings = data.get("data", {}).get("warnings", [])

# 6. Verify
if warnings:
    print(f"⚠️  Warnings: {warnings}")
    # Check for partial success / truncation
    result = terminal(
        "lark-cli docs +fetch --api-version v2 --doc DOC_TOKEN --as bot 2>&1"
    )
    # Parse and check all expected sections exist
```

## Pitfalls

1. **`str_replace` won't work for chapters** — pattern strings >3000 chars fail silently. Use `overwrite` instead.
2. **Must strip internal `<img>` tags** — Feishu `<img src="INTERNAL_TOKEN">` causes `degrade_code=3001` XML tokenization error
3. **Truncation is silent** — `overwrite` still returns `ok: true` even when content after the first bad img tag is dropped. Always verify with `fetch`.
4. **Recovery: use `append` for truncated content** — if content after img tags is dropped, reconstruct the missing XML (without img tags) and `+update --command append`
