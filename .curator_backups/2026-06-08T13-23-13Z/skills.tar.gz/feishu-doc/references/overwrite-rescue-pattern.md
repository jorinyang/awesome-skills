# Overwrite Rescue Pattern — 多变更级联修复

## 适用场景

以下任一条件满足时，放弃逐个 `str_replace`，改用此模式：

1. 需要对文档做 ≥3 处分散修改
2. 前序 `str_replace` 已造成内容损坏（XML 标签扁平化、内容重复、header 丢失）
3. 需要插入新的 XML block（callout、列表等），但 `str_replace` 会将其扁平化为纯文本
4. 修改涉及同一区域的多次操作，存在先后顺序依赖

## 工作流

### Step 1: Fetch 全文

```bash
lark-cli docs +fetch --api-version v2 --doc DOC_TOKEN --as bot 2>&1 | python3 -c "
import sys, json
raw = sys.stdin.read()
start = raw.index('{')
data = json.loads(raw[start:])
content = data['data']['document']['content']
with open('/tmp/doc_raw.xml', 'w') as f:
    f.write(content)
print(f'Fetched {len(content)} chars')
"
```

### Step 2: Python 一次性修复

```python
content = open('/tmp/doc_raw.xml').read()

# 修复项 1: 文本替换
content = content.replace('old_text', 'new_text')

# 修复项 2: 在两个 table 之间插入 callout + header
insertion_point = content.find('<table>', content.find('marker_before_table'))
callout_block = '''<callout emoji="✅" background-color="light-green" border-color="green">
  <p><b>标题</b></p>
  <ol><li seq="1">内容</li></ol>
</callout>
<h3>section header</h3>
'''
content = content[:insertion_point] + callout_block + content[insertion_point:]

# 修复项 3: 清理重复/残留内容
# 检查关键标记 count == 1
assert content.count('unique_marker') == 1, 'Duplicate found!'

# Step 3: 移除 <title> 防止幽灵节点
import re
content = re.sub(r'<title>.*?</title>', '', content, count=1)

with open('/tmp/doc_fixed.xml', 'w') as f:
    f.write(content)
```

### Step 3: Overwrite 回写

```bash
cd /tmp && lark-cli docs +update --api-version v2 --doc DOC_TOKEN \
  --command overwrite --doc-format xml \
  --content @doc_fixed.xml --as bot
```

### Step 4: 验证

```bash
lark-cli docs +fetch --api-version v2 --doc DOC_TOKEN --as bot 2>&1 | python3 -c "
import sys, json
raw = sys.stdin.read()
content = json.loads(raw[raw.index('{'):])['data']['document']['content']
checks = [
    ('callout intact', 'CEO 已确认' in content),
    ('header exists', '🟡 中期关注' in content),
    ('no duplicates', content.count('unique_marker') == 1),
]
for name, ok in checks:
    print(f'  {\"✅\" if ok else \"❌\"} {name}')
"
```

## 关键注意事项

1. **移除 `<title>`**：overwrite 含 `<title>` 会导致 Wiki 节点幽灵残留。用 `--new-title` 单独设标题，或在 overwrite 前从 XML 中移除 `<title>`。

2. **无内部图片检查**：如果文档包含 `<img src="...">`（带 `src` 属性的飞书内部图片），overwrite 会触发 `degrade_code=3001` 并截断后续内容。需提前移除这些标签或用 `<p><em>（照片需手动重新上传）</em></p>` 占位。

3. **验证不是可选的**：overwrite 后必须立即 fetch 验证。尤其检查：
   - 内容总字符数是否接近预期
   - 关键 marker 是否存在且不重复
   - XML block 标签是否完整（不是被扁平化）

4. **不要逐条修**：每轮 str_replace 失败会给下一轮制造更多障碍。一次修复全部问题，一次 overwrite 完成。

## 反面案例（本次教训）

试图用 3 次 `str_replace` 更新 CEO 决策：
1. 第一次：pattern 匹配 `<h3>🟡 中期关注</h3>`，替换为 callout XML → callout 被扁平化为 `<h3>` 纯文本（陷阱 1），且 header 被吃掉（陷阱 2）
2. 第二次：attempt to fix header → `</callout>` 不唯一，str_replace 失败
3. 第三次：append header → header 被追加到文档末尾，位置错误

累积损坏后，最终仍是 fetch → Python fix → overwrite 解决。
