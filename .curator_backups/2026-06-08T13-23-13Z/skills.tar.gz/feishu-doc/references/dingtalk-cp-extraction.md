# 钉钉文档 CP 协议内容提取

> 当浏览器渲染钉钉在线文档失败（SPA 页面，需 JS 执行）时，通过底层 CP（Collaborative Protocol）JSON 直接提取纯文本内容。

## 背景

钉钉在线文档（alidocs.dingtalk.com）是 SPA 应用，`browser_navigate` 或 `curl` 直接抓取只能得到 JS bundle，无法获取文档正文。但页面 HTML 中嵌入了 `cpUrl`，指向阿里云 OSS 上的 CP 协议 JSON，包含完整文档结构。

## 提取步骤

### Step 1：从页面提取 cpUrl

```bash
curl -sL --max-time 20 \
  -H 'User-Agent: Mozilla/5.0' \
  'https://alidocs.dingtalk.com/i/p/{USER_ID}/docs/{DOC_ID}' \
  | grep -oP '"cpUrl":"(https://[^"]+)"'
```

返回的 cpUrl 格式：
```
https://alidocs.oss-cn-zhangjiakou.aliyuncs.com/collab/{COLLAB_ID}/cp/{UUID}
```

### Step 2：获取 CP JSON 并解析

```python
import json, urllib.request

with urllib.request.urlopen(cp_url) as r:
    data = json.loads(r.read())

main = data['parts']['00000000-0000-0000-0000-000000000001']['data']['body']
```

### Step 3：递归提取文本和链接

CP 结构是嵌套 JSON 数组，文本在 `['span', {...attrs...}, ['span', {...}, "text"]]` 路径中。简化提取：

```python
def flat_text(node):
    out = []
    if isinstance(node, list):
        for item in node:
            out.append(flat_text(item))
    elif isinstance(node, dict):
        for k, v in node.items():
            if k == 'href':
                out.append(f"[链接:{v}]")
            else:
                out.append(flat_text(v))
    elif isinstance(node, str):
        if not node.startswith(('p','h','title','table','img','hr','a','span')):
            out.append(node)
    return ''.join(out)

def all_links(node, found=None):
    if found is None: found = []
    if isinstance(node, list):
        for item in node: all_links(item, found)
    elif isinstance(node, dict):
        if 'href' in node: found.append(node['href'])
        for v in node.values(): all_links(v, found)
    return found
```

### Step 4：递归提取子文档

钉钉文档的目录页（如 DEAP 使用指南）通过 `<a href="...">` 链接到子文档。对每个子文档重复 Step 1-3 可获取完整知识树。

## 文本块类型

| CP 标签 | 含义 | 处理方式 |
|---------|------|---------|
| `p` | 段落 | 提取内部文本 |
| `h1`–`h9` | 标题 | 提取文本，保留层级 |
| `title` | 文档标题 | 提取文本 |
| `table` | 表格 | 标注 `[TABLE]`（复杂结构需专项解析） |
| `img` | 图片 | 标注 `[IMAGE]`（文本不可直接提取） |
| `a` | 链接 | 提取 `href` + 显示文本 |
| `ol`/`ul` | 有序/无序列表 | 提取内部文本 |
| `hr` | 分隔线 | 忽略 |

## 限制

- **图片内容**：CP JSON 中的图片仅包含 `src`（内部文件 token），无法直接转换为文本。需通过 `browser_navigate` + OCR 或分步下载图片 → vision 识别。
- **表格**：CP 中的表格是嵌套 JSON 结构，简单 `flat_text` 会丢失行列关系。需专项解析。
- **SPA 页面**：非 CP 格式的钉钉文档（如新版 Docs）可能不暴露 cpUrl，需浏览器渲染。

## 使用场景

- 钉钉内部知识库文档批量提取
- DEAP/悟空等钉钉产品文档的离线分析
- 客户提供的钉钉需求文档自动化解析

## 参考

- 浙能燃气项目：通过 CP 提取 DEAP 使用指南完整模块矩阵（2.1-2.7，20+ 子文档）
