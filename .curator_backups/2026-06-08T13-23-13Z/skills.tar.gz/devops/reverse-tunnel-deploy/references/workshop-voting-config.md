# Workshop Voting — Deployment Configuration

## OSS Credentials
- **Endpoint**: `oss-cn-hongkong.aliyuncs.com`
- **Bucket**: `clawshell-vault`
- **Access Key**: `LTAI5tFk9VFxcwKiyqgSCska`
- **Secret**: `xXgvqS7ujupOukJMhT3SQygoy6haXj`

## Deployed Files
| Local Path | OSS Key |
|---|---|
| `/home/aorus/.hermes-feishu/output/workshop-voting/index.html` | `web-spa/workshop-voting/index.html` |

## Tunnel Config
- **Command**: `ssh -R 80:localhost:5050 nokey@localhost.run`
- **Local service**: port 5050
- **URL constant name**: `PROXY_URL` in HTML `<script>` block

## Known lhr.life URLs (rotated on restart)
- `https://f3f8f6bd402e15.lhr.life` (2026-06-06, proc `proc_e2e765d32656`, conn `119de7fa-c146-4a27-a076-caff9b448ccf`, **current**)
- `https://fd1eb5c07b9a73.lhr.life` (2026-06-06, same proc `proc_e2e765d32656`, same conn — mid-session reassignment, returned 503 after f3f8f6bd402e15 appeared)
- `https://d35766b5a2a10b.lhr.life` (2026-06-06, proc `proc_440ec5942c4e`, conn `5bdade2a-9b50-4ea6-80fb-51e5410e4e88`, dead)
- `https://b247e2d3639562.lhr.life` (2026-06-06, proc `proc_ce7bd3e2c9c3`, conn `ae3da7c5-fd08-4d5a-9ec4-74e51ad211b9`, dead — replaced by d35766b5a2a10b)
- `https://348207172e1169.lhr.life` (2026-06-06, proc `proc_265dee24b095`, conn unknown, dead — was deployed to HTML when tunnel check ran)
- `https://d22247874465a1.lhr.life` (2026-06-06, proc `proc_04cd585010d5`, conn `60004b90-c710-41e1-b4c7-ae45c308a71a`, dead)
- `https://ac5ffecfda76a6.lhr.life` (2026-06-06, proc unknown, deployed to HTML but tunnel died)
- `https://827e2cf06f25de.lhr.life` (2026-06-06, proc `proc_107d7cb3b7ae`, conn `43a3f4ef-2536-4520-b451-0d0aa307dbf3`, dead — process died)
- `https://508e1d8ac0a14d.lhr.life` (2026-06-06, proc `proc_e96124734c24`, conn `b9cdd42f-23b5-45de-946c-63e7c85998b4`, dead)
- `https://d8ac085601adac.lhr.life` (2026-06-06, proc `proc_265dee24b095`, conn `ac21fbd3-e15a-4b0a-a788-0f74e751022a`, dead — process died)
- `https://52ba750a8fed11.lhr.life` (2026-06-06, proc `proc_963fe389b412`, conn `2d789bb9-769e-44d8-a8a3-251b285af81f`, dead — process died)
- `https://0ddbc535c2a188.lhr.life` (2026-06-06, proc `proc_265dee24b095`, conn `ac21fbd3-e15a-4b0a-a788-0f74e751022a`, dead — was previous "current", process died)
- `https://04a4d7a193ce51.lhr.life` (2026-06-06, proc `proc_d07ed4a78613`, dead — no keepalive, died within seconds)
- `https://b036f20d6447dc.lhr.life` (2026-06-06, proc `proc_760f86220f90`, conn `a3aa3c57-b85a-4415-9f7d-e98877f8e928`, dead)
- `https://b79853758216de.lhr.life` (2026-06-06, foreground timeout capture, conn `667dadff-6627-4be4-96e5-fa2e48637ce8`, one-shot, never deployed)
- `https://c0d9183ccfb5d5.lhr.life` (2026-06-06, proc `proc_265dee24b095`, conn `ac21fbd3-e15a-4b0a-a788-0f74e751022a`, dead)
- `https://212f976811e91f.lhr.life` (2026-06-06, proc `proc_fefc10c715e5`, conn `b8c6f6c8-c89d-4801-98de-d7bcf25b09fb`, stale)
- `https://2ebd96fff88b1f.lhr.life` (2026-06-06, proc `proc_e39d60c9f018`, stale)
- `https://9a08a42f5a67e3.lhr.life` (2026-06-06, proc `proc_ce8f04713ded`, stale)
- `https://61f96839a18cf6.lhr.life` (2026-06-06, proc `proc_c5d609cc090a`, stale)
- `https://a6647952965a41.lhr.life` (2026-06-06, proc `proc_00feb5299100`, stale)
- `https://b995178bd416a1.lhr.life` (2026-06-06, connection `10ca7260-edb0-4cb6-b7bd-fa171e5638dc`, proc `proc_aaa19833b450`, stale)
- `https://dc1679263fdb06.lhr.life` (2026-06-06, connection `dc668a7f-57a2-4bde-9b6f-2232ac2af993`, proc `proc_2987149aa514`, stale)
- `https://827ec1766fb836.lhr.life` (2026-06-06, connection `5482e514-c83a-49e6-ac34-81ef5f2cab43`, proc `proc_2e4281884809`, stale)
- `https://07d0a06b7824a7.lhr.life` (2026-06-06, connection `0fe30688-4bd4-4534-bda7-2a5c1bbe1f68`, wrapper proc `proc_02ebf33fe242`)
- `https://da761c454638ba.lhr.life` (2026-06-06, connection `438690d3-0146-4c19-94b3-803b0d60d41a`, proc `proc_bea48ce82635`)
- `https://2fa443c97de1ee.lhr.life` (2026-06-06, connection `31cb896a-9280-4af7-bde7-0571159d0ece`, proc `proc_d21624ceba20`)
- `https://6fa91c218764bc.lhr.life` (2026-06-06, connection `73997a2f-a50f-4dbd-bf6a-2d6295eea137`)
- `https://d78849dc971503.lhr.life` (2026-06-06, connection `3d3d47d2`)
- `https://5309b739be3834.lhr.life` (2026-06-06, connection `bf803c71`)
- `https://58f06b31904278.lhr.life` (prior)
