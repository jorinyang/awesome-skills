#!/usr/bin/env python3
"""Start SSH tunnel to localhost.run, capture the URL, and keep it alive.

Spawns `ssh -T -R 80:localhost:PORT nokey@localhost.run`, reads stderr line
by line, extracts the lhr.life URL, writes it to URL_FILE, and holds the
connection open (by keeping stdin pipe alive).

Usage:
    python3 tunnel_wrapper.py [--port PORT] [--url-file PATH]

Environment variables:
    LOCAL_PORT  - local port to forward (default: 5050)
    URL_FILE    - where to write the captured URL (default: ./tunnel_url.txt)
"""

import subprocess
import sys
import re
import os
import time
import argparse


def main():
    parser = argparse.ArgumentParser(description="SSH tunnel to localhost.run with URL capture")
    parser.add_argument("--port", type=int, default=int(os.environ.get("LOCAL_PORT", "5050")),
                        help="Local port to forward (default: 5050)")
    parser.add_argument("--url-file", default=os.environ.get("URL_FILE", "tunnel_url.txt"),
                        help="File to write captured URL (default: ./tunnel_url.txt)")
    parser.add_argument("--remote-port", type=int, default=80,
                        help="Remote port on localhost.run (default: 80)")
    args = parser.parse_args()

    cmd = [
        "ssh", "-T",
        "-o", "StrictHostKeyChecking=no",
        "-o", "UserKnownHostsFile=/dev/null",
        "-o", "PubkeyAuthentication=no",
        "-o", "PreferredAuthentications=keyboard-interactive,password",
        "-o", "ConnectTimeout=10",
        "-o", "ServerAliveInterval=60",
        "-R", f"{args.remote_port}:localhost:{args.port}",
        "nokey@localhost.run",
    ]

    proc = subprocess.Popen(
        cmd,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        stdin=subprocess.PIPE,
        text=True,
        bufsize=1,
    )

    url_pattern = re.compile(r"(?:https?://)?([a-z0-9]+\.lhr\.life)")
    found_url = None
    url_written = False

    try:
        for line in proc.stdout:
            sys.stderr.write(line)
            sys.stderr.flush()
            match = url_pattern.search(line)
            if match and not url_written:
                found_url = "https://" + match.group(1)
                os.makedirs(os.path.dirname(args.url_file) or ".", exist_ok=True)
                with open(args.url_file, "w") as f:
                    f.write(found_url + "\n")
                print(f"URL_CAPTURED: {found_url}", flush=True)
                url_written = True
    except KeyboardInterrupt:
        pass
    finally:
        proc.terminate()
        proc.wait()


if __name__ == "__main__":
    main()
