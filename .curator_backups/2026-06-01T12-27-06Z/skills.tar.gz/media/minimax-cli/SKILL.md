---
name: minimax-cli
description: MiniMax CLI (mmx-cli) — 图片理解、视频/图片/音乐/语音生成、网络搜索，一站式多模态 CLI
triggers:
  - 识别图片/理解图片/分析图片/描述图片/图片内容/visual understanding
  - minimax/mmx/minimax-cli 相关
  - 用 MiniMax 生成视频/图片/音乐/语音
  - 需要参考图→文字描述嵌入 prompt 的场景
tags: [minimax, image-understanding, video-generation, multimodal, cli]
category: media
---

# MiniMax CLI (`mmx-cli`)

## 概述

`mmx-cli` 是 MiniMax 官方 CLI 工具，为 Agent 提供全模态能力：图片理解（VLM）、视频生成（Hailuo）、图片生成、音乐创作、语音合成、网络搜索。

- **npm 包**: `mmx-cli@1.0.15`
- **安装**: `npm install -g mmx-cli`
- **认证**: `mmx auth login --api-key <key>`（自动检测 region cn/global）
- **配额**: `mmx quota`

### WSL 环境

bin 链接在 WSL 中不可用，使用 node 直接执行：

```bash
MMX="node $(npm root -g)/mmx-cli/dist/mmx.mjs"
$MMX --help
```

## 核心命令

### 图片理解（vision describe）— 核心能力

```bash
$MMX vision describe --image ./ref.jpg --prompt "详细描述画面内容"
# 支持本地路径和 URL
# 输出 JSON：{"content": "...", "base_resp": {"status_code": 0}}
```

- 消耗 `coding-plan-vlm` 配额
- 默认 prompt "Describe the image."，建议自定义中文 prompt 获得更精准描述
- 典型用途：分析参考图 → 提取视觉描述 → 嵌入 jimeng/seedance prompt

### 视频生成

```bash
$MMX video generate --prompt "夕阳下，一只猫坐在窗边望向远方"
# 消耗 Hailuo 配额
```

### 图片生成

```bash
$MMX image generate --prompt "赛博朋克城市夜景，16:9"
```

### 音乐生成

```bash
$MMX music generate --prompt "轻快爵士风格，主题是夏天的海边" --out jazz-summer.mp3
```

### 语音合成

```bash
$MMX speech synthesize --text "欢迎使用 MiniMax" --out voiceover.mp3
```

### 文本对话

```bash
$MMX text chat --message "帮我生成一首关于AI的4言诗"
```

### 网络搜索

```bash
$MMX search query --query "贵州万峰林最佳旅游季节"
```

### 配额查询

```bash
$MMX quota
```

## 与 jimeng-video 集成

图片理解解决 Seedance 工作流中最关键的痛点 — 参考图识别：

```
参考图 → mmx vision describe → 文字描述 → 嵌入 jimeng video generate --prompt
```

无需切换视觉模型，无需人工描述参考图。详见 `jimeng-video` 技能的 `references/seedance-multi-shot-workflow.md`。

## 实测陷阱

- **WSL bin 不可用**：`mmx` 命令可能报 `command not found`，使用 `node $(npm root -g)/mmx-cli/dist/mmx.mjs` 直接执行
- **API Key 自动检测 region**：`mmx auth login` 会通过 API 探测自动选择 cn/global，无需手动设置
- **vision describe 输出 JSON**：内容在 `content` 字段，非 stdout 纯文本
- **配额类型**：vision 消耗 `coding-plan-vlm`，搜索消耗 `coding-plan-search`，视频消耗 `MiniMax-Hailuo-*`

## 环境状态

| 项目 | 值 |
|------|-----|
| 安装状态 | ✅ 已安装 (v1.0.15) |
| API Key | ✅ 已配置 (region cn) |
| vision describe | ✅ 已验证 |
