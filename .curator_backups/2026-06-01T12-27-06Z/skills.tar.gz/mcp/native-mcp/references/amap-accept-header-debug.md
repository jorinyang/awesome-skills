# amap MCP 2.0 Accept Header Debug Transcript

> 2026-05-30 — 排查 amap MCP StreamableHTTP 连接 500 错误全过程

## Problem

Gateway 日志持续报 500，但 curl 直接调用返回 200。

```
# Gateway log:
ERROR: MCP server 'amap' (HTTP): 500 Internal Server Error (3 retries, giving up)

# Curl test:
$ curl -X POST "https://mcp.amap.com/mcp?key=KEY" -H "Accept: application/json, text/event-stream" ...
→ 200 OK, server: amap-sse-server v1.0.0
```

## Root Cause

Amap MCP 2.0 server requires:
```
Accept: application/json, text/event-stream
```

The `mcp` Python SDK (v1.27.0) does not send this header by default. Without it, the server returns:
- Direct POST: `406 Not Acceptable`
- Through SDK: `500 Internal Server Error` (after negotiation failure)

## Diagnosis Steps

### 1. Verify server is alive (terminal curl)
```bash
curl -s -X POST "https://mcp.amap.com/mcp?key=KEY" \
  -H "Content-Type: application/json" \
  -H "Accept: application/json, text/event-stream" \
  -d '{"jsonrpc":"2.0","method":"initialize","params":{"protocolVersion":"2025-11-25","capabilities":{}},"id":1}'
# → 200 OK if server is up
```

### 2. Reproduce with Python httpx (no Accept header)
```python
import httpx
r = httpx.post("https://mcp.amap.com/mcp?key=KEY", json={...})
print(r.status_code)  # → 406
print(r.text)          # → "Client must accept both application/json and text/event-stream"
```

### 3. Fix: add Accept header
```python
r = httpx.post(
    "https://mcp.amap.com/mcp?key=KEY",
    json={...},
    headers={"Accept": "application/json, text/event-stream"}
)
print(r.status_code)  # → 200
```

## Fix in Config

```yaml
mcp_servers:
  amap:
    url: "https://mcp.amap.com/mcp?key=YOUR_KEY"
    headers:
      Accept: "application/json, text/event-stream"
    timeout: 30
```

## Related Issues

- SSE endpoint `https://mcp.amap.com/sse` returns 404 (confirmed 2026-05-30)
- `Authorization: Bearer KEY` header approach also fails (INVALID_USER_KEY)
- Only `?key=KEY` query parameter + Accept header works
